package com.example.controlmusic;

import java.io.Serializable;

public class Music implements Serializable {
    private String Name;
    private String Singer;
    private int Link;
    public Music(String name, String singer, int link) {
        this.Name = name;
        this.Singer = singer;
        this.Link = link;
    }
    public Music(){

    }
    public String getName() {
        return Name;
    }

    public void setName(String name) {
       this.Name = name;
    }

    public String getSinger() {
        return Singer;
    }

    public void setSinger(String singer) {
        this.Singer = singer;
    }

    public int getLink() {
      return  Link;
    }

    public void setLink(int link) {
        this.Link = link;
    }


}
