package com.example.controlmusic;

import android.content.Context;
import android.media.session.PlaybackState;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.app.NotificationCompat;
import android.support.v4.media.session.MediaButtonReceiver;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.MediaSessionCompat;

public class MediaStyle {
    public static NotificationCompat.Builder from(
            Context context, MediaSessionCompat mediaSessionCompat
    ){
        MediaControllerCompat controllerCompat=mediaSessionCompat.getController();
        MediaMetadataCompat metadataCompat=controllerCompat.getMetadata();
        MediaDescriptionCompat descriptionCompat= metadataCompat.getDescription();
        NotificationCompat.Builder builder=new NotificationCompat.Builder(context);
        builder
                .setContentTitle(descriptionCompat.getTitle())
                .setContentText(descriptionCompat.getSubtitle())
                .setSubText(descriptionCompat.getDescription())
                .setLargeIcon(descriptionCompat.getIconBitmap())
                .setContentIntent(controllerCompat.getSessionActivity())
                .setDeleteIntent(
                        MediaButtonReceiver.buildMediaButtonPendingIntent(context, PlaybackState.ACTION_STOP)
                )
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC);
        return builder;

    }
}
