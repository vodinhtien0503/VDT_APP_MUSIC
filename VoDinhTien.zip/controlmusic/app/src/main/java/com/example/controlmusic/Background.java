package com.example.controlmusic;

import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.AssetFileDescriptor;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.session.PlaybackState;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.ResultReceiver;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.XmlRes;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.support.v4.media.MediaBrowserCompat.MediaItem;
import android.support.v4.media.MediaBrowserServiceCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.session.MediaButtonReceiver;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.text.TextUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * This class provides a MediaBrowser through a service. It exposes the media library to a browsing
 * client, through the onGetRoot and onLoadChildren methods. It also creates a MediaSession and
 * exposes it through its MediaSession.Token, which allows the client to create a MediaController
 * that connects to and send control commands to the MediaSession remotely. This is useful for
 * user interfaces that need to interact with your media session, like Android Auto. You can
 * (should) also use the same service from your app's UI, which gives a seamless playback
 * experience to the user.
 * <p>
 * To implement a MediaBrowserService, you need to:
 *
 * <ul>
 *
 * <li> Extend {@link MediaBrowserServiceCompat}, implementing the media browsing
 * related methods {@link MediaBrowserServiceCompat#onGetRoot} and
 * {@link MediaBrowserServiceCompat#onLoadChildren};
 * <li> In onCreate, start a new {@link MediaSessionCompat} and notify its parent
 * with the session's token {@link MediaBrowserServiceCompat#setSessionToken};
 *
 * <li> Set a callback on the {@link MediaSessionCompat#setCallback(MediaSessionCompat.Callback)}.
 * The callback will receive all the user's actions, like play, pause, etc;
 *
 * <li> Handle all the actual music playing using any method your app prefers (for example,
 * {@link android.media.MediaPlayer})
 *
 * <li> Update playbackState, "now playing" metadata and queue, using MediaSession proper methods
 * {@link MediaSessionCompat#setPlaybackState(android.support.v4.media.session.PlaybackStateCompat)}
 * {@link MediaSessionCompat#setMetadata(android.support.v4.media.MediaMetadataCompat)} and
 * {@link MediaSessionCompat#setQueue(java.util.List)})
 *
 * <li> Declare and export the service in AndroidManifest with an intent receiver for the action
 * android.media.browse.MediaBrowserService
 *
 * </ul>
 * <p>
 * To make your app compatible with Android Auto, you also need to:
 *
 * <ul>
 *
 * <li> Declare a meta-data tag in AndroidManifest.xml linking to a xml resource
 * with a &lt;automotiveApp&gt; root element. For a media app, this must include
 * an &lt;uses name="media"/&gt; element as a child.
 * For example, in AndroidManifest.xml:
 * &lt;meta-data android:name="com.google.android.gms.car.application"
 * android:resource="@xml/automotive_app_desc"/&gt;
 * And in res/values/automotive_app_desc.xml:
 * &lt;automotiveApp&gt;
 * &lt;uses name="media"/&gt;
 * &lt;/automotiveApp&gt;
 *
 * </ul>
 */
public class Background extends MediaBrowserServiceCompat implements AudioManager.OnAudioFocusChangeListener {

    private MediaSessionCompat mediaSessionCompat;
    private MediaPlayer mediaPlayer;

    @Override
    public void onCreate() {
        super.onCreate();
        initMediaplayer();
        initMediaSession();
        initNoisyReceiver();
        //  mSession = new MediaSessionCompat(this, "Background");
        //setSessionToken(mSession.getSessionToken());
        //mSession.setCallback(new MediaSessionCallback());
        //mSession.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS |
        //      MediaSessionCompat.FLAG_HANDLES_TRANSPORT_CONTROLS);
    }

    private void initMediaplayer() {
        mediaPlayer =new MediaPlayer();
        mediaPlayer.setWakeMode(getApplicationContext(), PowerManager.PARTIAL_WAKE_LOCK);
        mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
        mediaPlayer.setVolume(1.0f,1.0f);
    }

    private void initMediaSession() {
        ComponentName mediaButtonReceiver =new ComponentName(getApplicationContext(), MediaButtonReceiver.class);
        mediaSessionCompat =new MediaSessionCompat(getApplicationContext(),"Tag",mediaButtonReceiver,null);
        mediaSessionCompat.setCallback(mediasessioncallback);
        mediaSessionCompat.setFlags(MediaSessionCompat.FLAG_HANDLES_MEDIA_BUTTONS);
        Intent mediaButtonIntent=new Intent(Intent.ACTION_MEDIA_BUTTON);
        mediaButtonIntent.setClass(this,MediaButtonReceiver.class);
        PendingIntent pendingIntent=  PendingIntent.getBroadcast(this,0,mediaButtonIntent,0);
        mediaSessionCompat.setMediaButtonReceiver(pendingIntent);
        setSessionToken(mediaSessionCompat.getSessionToken());
    }

    private void initNoisyReceiver() {
        IntentFilter intentFilter= new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY);
        registerReceiver(headReceiver,intentFilter);

    }
    private MediaSessionCompat.Callback mediasessioncallback=new MediaSessionCompat.Callback() {
        @Override
        public void onPlay() {
            super.onPlay();
            if(!successfullyRetrieveAudioFocus()){
                return;
            }
            mediaSessionCompat.setActive(true);
            setMediaPlaybackSttate(PlaybackStateCompat.STATE_PLAYING);
            showPlayingNotification();
            mediaPlayer.start();
        }

        @Override
        public void onPlayFromMediaId(String mediaId, Bundle extras) {
            super.onPlayFromMediaId(mediaId, extras);
            try {
                AssetFileDescriptor adf=getResources().openRawResourceFd(Integer.valueOf(mediaId));
                if (adf==null)
                    return;
                try {


                    mediaPlayer.setDataSource(adf.getFileDescriptor(), adf.getStartOffset(), adf.getLength());
                }
                catch (IllegalStateException eeeee){
                    mediaPlayer.release();
                    initMediaplayer();
                    mediaPlayer.setDataSource(adf.getFileDescriptor(),adf.getStartOffset(),adf.getLength());
                }
                adf.close();
                initMediaSessionMetaData();

            }
          catch (IOException e){
                return;
          }
            try {
                mediaPlayer.prepare();
            } catch (IOException e) {
                e.printStackTrace();
            }

        }

        @Override
        public void onPause() {
            super.onPause();
            if (mediaPlayer.isPlaying()){
                mediaPlayer.pause();
                setMediaPlaybackSttate(PlaybackStateCompat.STATE_PAUSED);
                showPauseNotification();
            }
        }
    };

    private void initMediaSessionMetaData() {
        MediaMetadataCompat.Builder meta= new MediaMetadataCompat.Builder();
        meta.putBitmap(MediaMetadataCompat.METADATA_KEY_ART, BitmapFactory.decodeResource(getResources(),R.mipmap.ic_launcher));
        meta.putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_TITLE,"Title");
        meta.putString(MediaMetadataCompat.METADATA_KEY_DISPLAY_SUBTITLE,"Art");
        meta.putLong(MediaMetadataCompat.METADATA_KEY_TRACK_NUMBER,1);
        meta.putLong(MediaMetadataCompat.METADATA_KEY_NUM_TRACKS,1);
        mediaSessionCompat.setMetadata(meta.build());

    }

    private void showPauseNotification() {
        NotificationCompat.Builder builder=MediaStyle.from(Background.this,mediaSessionCompat);
        if (builder==null)
            return;
        builder.addAction(new NotificationCompat.Action(android.R.drawable.ic_media_play,"Play",
                MediaButtonReceiver.buildMediaButtonPendingIntent(this,PlaybackState.ACTION_PLAY_PAUSE)));
        builder.setStyle(new android.support.v4.media.app.NotificationCompat.MediaStyle()
                .setShowActionsInCompactView(0).setMediaSession(mediaSessionCompat.getSessionToken()));
        builder.setSmallIcon(R.mipmap.ic_launcher);
        NotificationManagerCompat.from(Background.this).notify(1,builder.build());
    }

    private void showPlayingNotification() {
        NotificationCompat.Builder builder=MediaStyle.from(Background.this,mediaSessionCompat);
        if (builder==null)
            return;
        builder.addAction(new NotificationCompat.Action(android.R.drawable.ic_media_pause,"Pause",
                MediaButtonReceiver.buildMediaButtonPendingIntent(this,PlaybackState.ACTION_PLAY_PAUSE)));
        builder.setStyle(new android.support.v4.media.app.NotificationCompat.MediaStyle()
                .setShowActionsInCompactView(0).setMediaSession(mediaSessionCompat.getSessionToken()));
        builder.setSmallIcon(R.mipmap.ic_launcher);
        NotificationManagerCompat.from(Background.this).notify(1,builder.build());

    }

    private void setMediaPlaybackSttate(int statePlaying) {
        PlaybackStateCompat.Builder playbuilder= new PlaybackStateCompat.Builder();
        if(statePlaying==PlaybackStateCompat.STATE_PLAYING){
            playbuilder.setActions(PlaybackStateCompat.ACTION_PLAY_PAUSE|PlaybackStateCompat.ACTION_PLAY);
        }
        else {
            playbuilder.setActions(PlaybackStateCompat.ACTION_PLAY_PAUSE|PlaybackStateCompat.ACTION_PLAY);
            playbuilder.setState(statePlaying,PlaybackStateCompat.PLAYBACK_POSITION_UNKNOWN,0);
            mediaSessionCompat.setPlaybackState(playbuilder.build());
        }
    }

    private Boolean successfullyRetrieveAudioFocus(){
        AudioManager audioManager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
        int result=audioManager.requestAudioFocus(this,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN);
        return  result==AudioManager.AUDIOFOCUS_GAIN;
    }
    @Override
    public void onDestroy() {
        AudioManager manager= (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        manager.abandonAudioFocus(this);
        unregisterReceiver(noisyReceiver);
        mediaSessionCompat.release();
        NotificationManagerCompat.from(this).cancel(1);
    }
    private BroadcastReceiver noisyReceiver=new BroadcastReceiver(){

        @Override
        public void onReceive(Context context, Intent intent) {
            if (mediaPlayer!=null&&mediaPlayer.isPlaying()){
                mediaPlayer.pause();
            }
        }
    };

    @Override
    public BrowserRoot onGetRoot(@NonNull String clientPackageName,
                                 int clientUid,
                                 Bundle rootHints) {
        if(TextUtils.equals(clientPackageName,getPackageName())){
            return new BrowserRoot(getString(R.string.app_name),null);

        }
        return null;
    }

    @Override
    public void onLoadChildren(@NonNull final String parentMediaId,
                               @NonNull final Result<List<MediaItem>> result) {
        result.sendResult(new ArrayList<MediaItem>());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        MediaButtonReceiver.handleIntent(mediaSessionCompat,intent);
        return super.onStartCommand(intent, flags, startId);
    }
    private BroadcastReceiver headReceiver =new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(mediaPlayer!=null&&mediaPlayer.isPlaying()){
                mediaPlayer.pause();
            }
        }
    };

    @Override
    public void onAudioFocusChange(int focusChange) {
        switch (focusChange){
            case AudioManager.AUDIOFOCUS_LOSS:
                if(mediaPlayer.isPlaying()){
                    mediaPlayer.stop();
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK:
                if(mediaPlayer!=null){
                    mediaPlayer.setVolume(0.3f,0.3f);
                }
                break;
            case AudioManager.AUDIOFOCUS_LOSS_TRANSIENT:
                mediaPlayer.pause();
                break;
            case AudioManager.AUDIOFOCUS_GAIN:
                if(mediaPlayer!=null){
                    if (mediaPlayer.isPlaying()){
                        mediaPlayer.start();
                        mediaPlayer.setVolume(1.0f,1.0f);

                    }
                    break;
                }
        }
    }

    private final class MediaSessionCallback extends MediaSessionCompat.Callback {
        @Override
        public void onPlay() {
        }

        @Override
        public void onSkipToQueueItem(long queueId) {
        }

        @Override
        public void onSeekTo(long position) {
        }

        @Override
        public void onPlayFromMediaId(String mediaId, Bundle extras) {
        }

        @Override
        public void onPause() {
        }

        @Override
        public void onStop() {
        }

        @Override
        public void onSkipToNext() {
        }

        @Override
        public void onSkipToPrevious() {
        }

        @Override
        public void onCustomAction(String action, Bundle extras) {
        }

        @Override
        public void onPlayFromSearch(final String query, final Bundle extras) {
        }
    }
}
