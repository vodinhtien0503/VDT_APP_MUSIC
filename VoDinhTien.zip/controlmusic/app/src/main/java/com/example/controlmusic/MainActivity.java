package com.example.controlmusic;

import android.content.ComponentName;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.RemoteException;
import android.support.v4.media.MediaBrowserCompat;
import android.support.v4.media.session.MediaControllerCompat;
import android.support.v4.media.session.PlaybackStateCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.mikhaellopez.circularimageview.CircularImageView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class MainActivity extends AppCompatActivity  {
ImageButton shuffle,back,play,next,exchange,clock,favorite;
TextView name,namesingle,namesmall,tvtimestart,tvtimefinal;
ArrayList<Music> music;
CircularImageView imageView;
Animation anim;
private static final int STATE_PAUSED=0;
private static final int STATE_PLAYING=1;
private MediaBrowserCompat mediaBrowserCompat;
private MediaPlayer mediaPlayer;
private Handler mHandler =new Handler();
private SeekBar seekBar;
private double start=0;
private double finaltime=0;
private int forwardrime=5000;
private int backwardtime=5000;
private  int Check=0;
public static int onetimeonly=0;
int currentstate;
int position=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        music = new ArrayList<Music>();
        final Music music1 = new Music("Haru Haru", "Big bang", R.raw.haru_haru);
        Music music2 = new Music("Blue", "Big bang", R.raw.bang_bang);
        Music music3 = new Music("If you", "Big bang", R.raw.if_you);
        Music music4 = new Music("Fantasitc baby", "Big bang", R.raw.fantastic_baby);
        music.add(music1);
        music.add(music2);
        music.add(music3);
        music.add(music4);
        imageView=(CircularImageView)findViewById(R.id.image) ;
        shuffle = (ImageButton) findViewById(R.id.shuffle);
        back = (ImageButton) findViewById(R.id.back);
        play = (ImageButton) findViewById(R.id.play);
        next = (ImageButton) findViewById(R.id.next);
        exchange = (ImageButton) findViewById(R.id.exchange);
        clock = (ImageButton) findViewById(R.id.clock);
        favorite = (ImageButton) findViewById(R.id.favorite);
        name = (TextView) findViewById(R.id.tvname);
        namesingle = (TextView) findViewById(R.id.txnamesingle);
        namesmall = (TextView) findViewById(R.id.tvnamesmall);
        tvtimestart=(TextView)findViewById(R.id.timestart);
        tvtimefinal=(TextView)findViewById(R.id.timeend);
        seekBar = (SeekBar) findViewById(R.id.seekbar);
        seekBar.setClickable(false);
        shuffle.setClickable(false);
        exchange.setClickable(false);
        mediaBrowserCompat =new MediaBrowserCompat(this,new ComponentName(this,Background.class),con,getIntent().getExtras());
        mediaBrowserCompat.connect();
        setup();
        settime();
        autonext();

            favorite.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setSelected(!v.isSelected());
                    if (v.isSelected()) {
                        favorite.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_heart__red));
                    } else {
                        favorite.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_heart));
                    }
                }
            });
            shuffle.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setSelected(!v.isSelected());
                    if(v.isSelected()){
                       exchange.setEnabled(false);
                    }
                    else {
                        exchange.setEnabled(true);
                    }
                }
            });
            back.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setSelected(!v.isSelected());
                    position--;
                    if(position<0){
                        position=music.size()-1;
                    }
                    if(shuffle.isClickable()==true) {
                        Random rd = new Random();
                        int gh = music.size();
                        position = rd.nextInt(gh);
                        if (position < 0) {
                            position = music.size() - 1;

                        }
                    }
                    if (mediaPlayer.isPlaying()){
                        mediaPlayer.stop();
                    }
                    play.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_pause));
                   setup();
                   mediaPlayer.start();
                    settime();
                }


            });

            play.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setSelected(!v.isSelected());
                    if(shuffle.isClickable()==true) {
                        Random rd = new Random();
                        int gh = music.size();
                        position = rd.nextInt(gh);
                        if (position < 0) {
                            position = music.size() - 1;

                        }
                    }
                    if (v.isSelected()) {
                        anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.animation);
                        imageView.startAnimation(anim);
                        play.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_pause));
                        playaction(v);
                       // MediaControllerCompat.getMediaController(MainActivity.this)
                         //       .getTransportControls().play();
                        //currentstate=STATE_PLAYING;
                    } else {
                           // MediaControllerCompat.getMediaController(MainActivity.this)
                            //        .getTransportControls().pause();
                        //mediaBrowserCompat.disconnect();
                        play.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_play_arrow));
                        Pause(v);
                        imageView.clearAnimation();
                    }
                }
            });
            next.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setSelected(!v.isSelected());
                    position++;
                    if(position>music.size()-1){
                        position=0;
                    }
                    if(shuffle.isClickable()==true) {
                        Random rd = new Random();
                        int gh = music.size();
                        position = rd.nextInt(gh);
                        if (position < 0) {
                            position = music.size() - 1;

                        }
                    }
                    if (mediaPlayer.isPlaying()){
                        mediaPlayer.stop();
                    }
                    play.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_pause));
                    setup();
                    mediaPlayer.start();
                       settime();
                    }

            });
            exchange.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setSelected(!v.isSelected());
                    if(v.isSelected()){
                        mediaPlayer.setLooping(true);
                        shuffle.setEnabled(false);
                    }
                    else {
                        mediaPlayer.setLooping(false);
                        shuffle.setEnabled(true);
                    }
                }
            });
            clock.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    v.setSelected(!v.isSelected());
                    if (v.isSelected()) {
                        clock.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_alarm_clock__black));
                    } else {
                        clock.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_alarm_clock_white));
                    }
                }
            });
        }

    private Runnable UpdateTime= new Runnable() {
        @Override
        public void run() {
            start=mediaPlayer.getCurrentPosition();
            seekBar.setProgress((int)start);
            mHandler.postDelayed(this,100);

        }
    };
    public void playaction(View v){
        mediaPlayer.start();
        finaltime=mediaPlayer.getDuration();
        start=mediaPlayer.getCurrentPosition();
        if(onetimeonly==0){
            seekBar.setMax((int)finaltime);
            onetimeonly=1;
        }
        seekBar.setProgress((int)start);
        mHandler.postDelayed(UpdateTime,50);
    }
    public void Pause(View v){
        mediaPlayer.pause();
    }
    public void next(View v){
        int temp=(int)start;
        if((temp+forwardrime)<=finaltime){
          start=start+forwardrime;
          mediaPlayer.seekTo((int)start);
        }
    }
    public void  back(View v){
        int temp=(int)start;
        if(temp-backwardtime>0){
            start=start-backwardtime;
            mediaPlayer.seekTo((int)start);
        }
    }
    public void setup(){
        mediaPlayer = MediaPlayer.create(MainActivity.this, music.get(position).getLink());
        name.setText(music.get(position).getName() + "");
        namesingle.setText(music.get(position).getSinger() + "");
        namesmall.setText(music.get(position).getName() + "");
    }
    public void settime(){
        seekBar.setMax(mediaPlayer.getDuration());
        SimpleDateFormat time1= new SimpleDateFormat("mm:ss");
        tvtimestart.setText(time1.format(mediaPlayer.getCurrentPosition()));
        tvtimefinal.setText(time1.format(mediaPlayer.getDuration()));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                SimpleDateFormat time1= new SimpleDateFormat("mm:ss");
                tvtimestart.setText(time1.format(mediaPlayer.getCurrentPosition()));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mediaPlayer.seekTo(seekBar.getProgress());
                SimpleDateFormat time = new SimpleDateFormat("mm:ss");
                Toast.makeText(MainActivity.this, time.format(seekBar.getProgress()) + "", Toast.LENGTH_SHORT).show();

            }
        });
    }
    public void autonext(){
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                position++;

                if(position>music.size()-1){
                    position=0;

                }
                if(mediaPlayer.isPlaying()){
                    mediaPlayer.stop();
                }
                if(shuffle.isClickable()==true){
                    Collections.shuffle(music);
                }
                setup();
                mediaPlayer.start();
                settime();
                autonext();
            }
        });
    }
private MediaControllerCompat.Callback mediaControllerCallback= new MediaControllerCompat.Callback() {
    @Override
    public void onPlaybackStateChanged(PlaybackStateCompat state) {
        super.onPlaybackStateChanged(state);
        if (state==null)
            return;
        switch (state.getState()){
            case PlaybackStateCompat.STATE_PLAYING:
                currentstate=STATE_PLAYING;
                break;
            case PlaybackStateCompat.STATE_PAUSED:
                currentstate=STATE_PAUSED;
                break;
        }

    }
};
MediaBrowserCompat.ConnectionCallback con =new MediaBrowserCompat.ConnectionCallback(){
    @Override
    public void onConnected() {
        super.onConnected();
        try {
            MediaControllerCompat mediaControllerCompat=new MediaControllerCompat(MainActivity.this,
                    mediaBrowserCompat.getSessionToken());
            mediaControllerCompat.registerCallback(mediaControllerCallback);
            MediaControllerCompat.setMediaController(MainActivity.this,mediaControllerCompat);
            MediaControllerCompat.getMediaController(MainActivity.this).getTransportControls()
                                                                       .playFromMediaId(String.valueOf(music.get(position).getLink()),null);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }
};
}
