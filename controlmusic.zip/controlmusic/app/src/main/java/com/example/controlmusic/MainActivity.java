package com.example.controlmusic;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {
ImageButton shuffle,back,play,next,exchange,clock,favorite;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        shuffle= (ImageButton) findViewById(R.id.shuffle);
        back=(ImageButton) findViewById(R.id.back);
        play=(ImageButton) findViewById(R.id.play);
        next=(ImageButton) findViewById(R.id.next);
        exchange=(ImageButton) findViewById(R.id.exchange);
        clock=(ImageButton)findViewById(R.id.clock) ;
        favorite=(ImageButton) findViewById(R.id.favorite);
        favorite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setSelected(!v.isSelected());
                if(v.isSelected()){
                  favorite.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_heart__red));
                }
                else {
                    favorite.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_heart));
                }
            }
        });
        shuffle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setSelected(!v.isSelected());
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setSelected(!v.isSelected());
                if(v.isSelected()){

                }
                else {

                }
            }
        });
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setSelected(!v.isSelected());
                if(v.isSelected()){
               play.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_pause));
                }
                else {
                    play.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_play_arrow));
                }
            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setSelected(!v.isSelected());
            }
        });
        exchange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setSelected(!v.isSelected());
            }
        });
        clock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setSelected(!v.isSelected());
                if(v.isSelected()){
                clock.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_alarm_clock__black));
                }
                else {
                    clock.setImageDrawable(getBaseContext().getResources().getDrawable(R.drawable.ic_alarm_clock_white));
                }
            }
        });
    }
}
